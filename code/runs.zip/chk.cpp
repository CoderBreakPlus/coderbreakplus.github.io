#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef unsigned long long ull;

// 使用三个大质数加强哈希，避免子串比较时发生哈希冲突
const int mod[3] = {1000000007, 1000000009, 998244353};
int base_hsh[3];

int n;
char s[1000005];
int pw[3][1000005];
int hsh[3][1000005];

inline int gethash(int l, int r, int o) {
    return (hsh[o][r] + (ull)(mod[o] - hsh[o][l - 1]) * pw[o][r - l + 1]) % mod[o];
}

inline int lcp(int x, int y) {
    int l = 1, r = n - max(x, y) + 1, ret = 0;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (gethash(x, x + mid - 1, 0) == gethash(y, y + mid - 1, 0) &&
            gethash(x, x + mid - 1, 1) == gethash(y, y + mid - 1, 1) &&
            gethash(x, x + mid - 1, 2) == gethash(y, y + mid - 1, 2))
            ret = mid, l = mid + 1;
        else r = mid - 1;
    }
    return ret;
}

inline int lcs(int x, int y) {
    int l = 1, r = min(x, y), ret = 0;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (gethash(x - mid + 1, x, 0) == gethash(y - mid + 1, y, 0) &&
            gethash(x - mid + 1, x, 1) == gethash(y - mid + 1, y, 1) &&
            gethash(x - mid + 1, x, 2) == gethash(y - mid + 1, y, 2))
            ret = mid, l = mid + 1;
        else r = mid - 1;
    }
    return ret;
}

vector<tuple<int, int, int>> runs;

inline int cmp(int x, int y) {
    int p = lcp(x, y);
    return s[x + p] < s[y + p];
}

inline void get(int l, int r) {
    if (r > n || s[l] != s[r]) return;
    int r1 = r + lcp(l, r) - 1, l1 = l - lcs(l, r) + 1;
    if (r1 - l1 + 1 >= 2 * (r - l)) runs.emplace_back(l1, r1, r - l);
}

int z[1000005], tot;

inline void lyndon(int o) {
    z[0] = n + 1, tot = 0;
    for (int i = n; i >= 1; i--) {
        while (tot && cmp(i, z[tot]) == o) --tot;
        get(i, z[tot]);
        z[++tot] = i;
    }
}

void calc_runs(const string& str, ll& s1, ll& s2, ll& s3) {
    n = str.length();
    for (int i = 1; i <= n; i++) s[i] = str[i - 1];
    s[n + 1] = 0;

    for (int o = 0; o < 3; ++o) {
        pw[o][0] = 1;
        for (int i = 1; i <= n; i++)
            pw[o][i] = (ull)pw[o][i - 1] * base_hsh[o] % mod[o];
        for (int i = 1; i <= n; i++)
            hsh[o][i] = ((ull)hsh[o][i - 1] * base_hsh[o] + s[i]) % mod[o];
    }

    runs.clear();
    lyndon(0), lyndon(1);
    sort(runs.begin(), runs.end());
    runs.erase(unique(runs.begin(), runs.end()), runs.end());

    s1 = 0, s2 = 0, s3 = 0;
    for (auto& sb : runs) {
        int l = std::get<0>(sb);
        int r = std::get<1>(sb);
        int p = std::get<2>(sb);

        s1++;
        s2 += (r - l - 2 * p + 2);
        s3 += (r - l + 1);
    }
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    // 随机化哈希基底，使其免受任何特定模式的 Hack
    base_hsh[0] = rnd.next(10000, 100000000);
    base_hsh[1] = rnd.next(10000, 100000000);
    base_hsh[2] = rnd.next(10000, 100000000);

    // 读取选手的选项
    int op = ouf.readInt(1, 2, "op");

    if (op == 1) {
        // 读取选手的答案
        ll u1 = ouf.readLong();
        ll u2 = ouf.readLong();
        ll u3 = ouf.readLong();

        // 从 .ans 答案文件中直接读取预期答案
        // 根据题意，标准答案文件的格式也是第一行为 op，接下来三行为答案
        int ans_op = ans.readInt();
        ll a1 = ans.readLong();
        ll a2 = ans.readLong();
        ll a3 = ans.readLong();

        if (u1 == a1 && u2 == a2 && u3 == a3) {
            quitf(_ok, "Correct");
        } else {
            quitf(_wa, "Wrong Answer: expected %lld %lld %lld, found %lld %lld %lld", a1, a2, a3, u1, u2, u3);
        }
    } else {
        // 对于构造题部分，需要验证给出的字符串长度为 10^5 并现场计算得分
        string s1 = ouf.readWord();
        string s2 = ouf.readWord();
        string s3 = ouf.readWord();

        if (s1.length() != 100000 || s2.length() != 100000 || s3.length() != 100000) {
            quitf(_wa, "Length of all strings must be exactly 10^5");
        }

        ll a1_1, a2_1, a3_1;
        calc_runs(s1, a1_1, a2_1, a3_1);

        ll a1_2, a2_2, a3_2;
        calc_runs(s2, a1_2, a2_2, a3_2);

        ll a1_3, a2_3, a3_3;
        calc_runs(s3, a1_3, a2_3, a3_3);

        double n_val = 100000.0;
        
        double t1 = (double)a1_1 / n_val;
        double t2 = (double)a2_2 / (n_val * log2(n_val));
        double t3 = (double)a3_3 / (n_val * n_val);
        
        double score = 70.0 * t1 + 105.0 * t2 + 530.0 * t3;
        
        quitp(score/100, "Score=%.2f (T1:%.2f, T2:%.2f, T3:%.2f)", score, 70.0*t1, 105.0*t2, 530.0*t3);
    }
    return 0;
}